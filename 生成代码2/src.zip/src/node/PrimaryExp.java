package node;

public interface PrimaryExp {
    String getType();

    void setType(String type);
}
